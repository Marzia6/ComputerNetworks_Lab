import socket

frmt = "utf-8"
HEADER = 64
hostname = socket.gethostname()
SERVER = socket.gethostbyname(hostname)
port = 7000
disconnect_text = "End"
ADDR = (SERVER, port)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)


def send_message(message):
    encoded_message = message.encode(frmt)
    msg_length = len(encoded_message)
    msg_length = str(msg_length).encode(frmt)
    msg_length += b" " * (HEADER - len(msg_length))
    client.send(msg_length)
    client.send(encoded_message)
    print(client.recv(2048).decode(frmt))

message = f"The hostname of client is {socket.gethostname()} and the IP is {SERVER}"
send_message(message)
send_message(disconnect_text)
