import socket

frmt = "utf-8"
HEADER = 64
hostname = socket.gethostname()
SERVER = socket.gethostbyname(hostname)
port = 7000
disconnect_text = "End"
ADDR = (SERVER, port)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)

def send_message(message):
    encoded_message = message.encode(frmt)
    msg_length = len(encoded_message)
    msg_length = str(msg_length).encode(frmt)
    msg_length += b" " * (HEADER - len(msg_length))
    client.send(msg_length)
    client.send(encoded_message)

    if message != disconnect_text:  
        print(client.recv(2048).decode(frmt))

while True:
    inp = input("Enter a word/sentence: ")
    send_message(inp)
    if inp == disconnect_text:  
        break
