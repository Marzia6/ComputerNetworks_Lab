import socket
import threading  

frmt = "utf-8"
HEADER = 64
hostname = socket.gethostname()
SERVER = socket.gethostbyname(hostname)
port = 7000
disconnect_text = "End"
ADDR = (SERVER, port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
print("SERVER IS STARTING.......")

server.listen()
print("SERVER IS LISTENING ON", SERVER)

def handle_clients(conn, addr):
    print("Connected to", addr)
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(frmt)
        if msg_length:
            print("Length of message is", msg_length)
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(frmt)

            if msg == disconnect_text:
                connected = False
                conn.send(f"TERMINATING THE CONNECTION WITH{addr}".encode(frmt))
                print("Terminated connection with", addr)
            else:
                vowels = "aeiouAEIOU"
                count = sum(1 for i in msg if i in vowels)

                if count == 0:
                    conn.send("Not enough vowels I guess".encode(frmt))
                elif count <= 2:
                    conn.send("Enough vowels I guess".encode(frmt))
                else:
                    conn.send("Too many vowels".encode(frmt))
    conn.close()


while True:
    conn, addr = server.accept()
    thread = threading.Thread(target=handle_clients, args=(conn, addr))
    thread.start()

