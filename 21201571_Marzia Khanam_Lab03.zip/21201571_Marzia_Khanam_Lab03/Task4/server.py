import socket

frmt = "utf-8"
HEADER = 64
hostname = socket.gethostname()
SERVER = socket.gethostbyname(hostname)
port = 7000
disconnect_text = "End"
ADDR = (SERVER, port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
print("SERVER IS STARTING.......")

server.listen()
print("SERVER IS LISTENING ON", SERVER)
while True:
    conn, addr = server.accept()
    print("Connected to", addr)
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(frmt)
        print("Length of message is", msg_length)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(frmt)

            if msg == disconnect_text:
                connected = False
                conn.send(f"TERMINATING THE CONNECTION WITH{addr}".encode(frmt))
                print("Terminated connection with", addr)
            else:
                h = int(msg)
                salary = 0
                if h <= 40:
                    salary = h * 200
                else:
                    salary = 8000 + (h - 40) * 300
                conn.send(f"Salary of the person is :{salary}".encode(frmt))

    conn.close()
